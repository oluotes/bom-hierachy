CREATE TABLE orderS
(
   id   varchar(5),
   item   varchar(250)
   
)